
     var tree;
          
     function treeInit() {
     tree = new YAHOO.widget.TreeView("treeDiv1");
     var root = tree.getRoot();
    
	
	var objDITAOpenToolkitUserGuide = { label: "DITA Open Toolkit User Guide", href:"DITAOT_UGRef_bkinfo.html", target:"contentwin" };
    var DITAOpenToolkitUserGuide = new YAHOO.widget.TextNode(objDITAOpenToolkitUserGuide, root, false);
	var objColophon = { label: "Colophon", href:"DITAOT_UGRef_preface.html", target:"contentwin" };
    var Colophon = new YAHOO.widget.TextNode(objColophon, root, false);
	
	var objRelease122information = { label: "Release 1.2.2 information", href:"release_current/release_current.html", target:"contentwin" };
    var Release122information = new YAHOO.widget.TextNode(objRelease122information, root, false);
		var objSystemrequirementsandsupportedapplications = { label: "System requirements and supported applications", href:"release_current/sysreqs.html", target:"contentwin" };
    var Systemrequirementsandsupportedapplications = new YAHOO.widget.TextNode(objSystemrequirementsandsupportedapplications, Release122information, false);
		var objKnownproblems = { label: "Known problems", href:"release_current/knownproblems.html", target:"contentwin" };
    var Knownproblems = new YAHOO.widget.TextNode(objKnownproblems, Release122information, false);
	
	
	var objReleasehistory = { label: "Release history", href:"release_history/release_history.html", target:"contentwin" };
    var Releasehistory = new YAHOO.widget.TextNode(objReleasehistory, root, false);
	
	
	var objIntroduction = { label: "Introduction", href:"introduction/introduction.html", target:"contentwin" };
    var Introduction = new YAHOO.widget.TextNode(objIntroduction, root, false);
		var objAboutDarwinInformationTypingArchitectureDITA = { label: "About Darwin Information Typing Architecture (DITA)", href:"introduction/aboutdita.html", target:"contentwin" };
    var AboutDarwinInformationTypingArchitectureDITA = new YAHOO.widget.TextNode(objAboutDarwinInformationTypingArchitectureDITA, Introduction, false);
		var objAboutDITAOpenToolkitDITAOT = { label: "About DITA Open Toolkit (DITA OT)", href:"introduction/aboutditaot.html", target:"contentwin" };
    var AboutDITAOpenToolkitDITAOT = new YAHOO.widget.TextNode(objAboutDITAOpenToolkitDITAOT, Introduction, false);
		var objAboutthisdocument = { label: "About this document", href:"introduction/aboutditaotugref.html", target:"contentwin" };
    var Aboutthisdocument = new YAHOO.widget.TextNode(objAboutthisdocument, Introduction, false);
	
	
	var objGettingstarted = { label: "Getting started", href:"gettingstarted/gettingstarted.html", target:"contentwin" };
    var Gettingstarted = new YAHOO.widget.TextNode(objGettingstarted, root, false);
		
	
	var objGettinginformationgeneral = { label: "Getting information (general)", href:"gettinginformation/gettinginformation.html", target:"contentwin" };
    var Gettinginformationgeneral = new YAHOO.widget.TextNode(objGettinginformationgeneral, root, false);
		
	
	var objEvaluatingDITAandDITAOpenToolkit = { label: "Evaluating DITA and DITA Open Toolkit", href:"evaluating/evaluating.html", target:"contentwin" };
    var EvaluatingDITAandDITAOpenToolkit = new YAHOO.widget.TextNode(objEvaluatingDITAandDITAOpenToolkit, root, false);
		var objTheDITAauthoringproductionframework = { label: "The DITA authoring/production framework", href:"evaluating/framework.html", target:"contentwin" };
    var TheDITAauthoringproductionframework = new YAHOO.widget.TextNode(objTheDITAauthoringproductionframework, EvaluatingDITAandDITAOpenToolkit, false);
		var objUsecases = { label: "Use cases", href:"evaluating/usecases.html", target:"contentwin" };
    var Usecases = new YAHOO.widget.TextNode(objUsecases, EvaluatingDITAandDITAOpenToolkit, false);
		var objUsecasetemplate = { label: "Use case template", href:"evaluating/usecase_template.html", target:"contentwin" };
    var Usecasetemplate = new YAHOO.widget.TextNode(objUsecasetemplate, EvaluatingDITAandDITAOpenToolkit, false);
		var objProductionnotesevaluating = { label: "Production notes (evaluating)", href:"evaluating/evaluating_production_notes.html", target:"contentwin" };
    var Productionnotesevaluating = new YAHOO.widget.TextNode(objProductionnotesevaluating, EvaluatingDITAandDITAOpenToolkit, false);
		var objFormoreinformationevaluating = { label: "For more information (evaluating)", href:"evaluating/evaluating_formoreinfo.html", target:"contentwin" };
    var Formoreinformationevaluating = new YAHOO.widget.TextNode(objFormoreinformationevaluating, EvaluatingDITAandDITAOpenToolkit, false);
	
	
	var objInstallingandupgradingDITAOpenToolkit = { label: "Installing and upgrading DITA Open Toolkit", href:"installing/installing.html", target:"contentwin" };
    var InstallingandupgradingDITAOpenToolkit = new YAHOO.widget.TextNode(objInstallingandupgradingDITAOpenToolkit, root, false);
		var objInstallationoverview = { label: "Installation overview", href:"installing/installing_overview.html", target:"contentwin" };
    var Installationoverview = new YAHOO.widget.TextNode(objInstallationoverview, InstallingandupgradingDITAOpenToolkit, false);
			var objInstallingtherequiredtools = { label: "Installing the required tools", href:"installing/installing_required_tools.html", target:"contentwin" };
    var Installingtherequiredtools = new YAHOO.widget.TextNode(objInstallingtherequiredtools, Installationoverview, false);
			var objInstallingtheoptionaltools = { label: "Installing the optional tools", href:"installing/installing_optional_tools.html", target:"contentwin" };
    var Installingtheoptionaltools = new YAHOO.widget.TextNode(objInstallingtheoptionaltools, Installationoverview, false);
			var objInstallationconsiderations = { label: "Installation considerations", href:"installing/installing_considerations.html", target:"contentwin" };
    var Installationconsiderations = new YAHOO.widget.TextNode(objInstallationconsiderations, Installationoverview, false);
		
		var objUpgradeoverview = { label: "Upgrade overview", href:"installing/upgrading_overview.html", target:"contentwin" };
    var Upgradeoverview = new YAHOO.widget.TextNode(objUpgradeoverview, InstallingandupgradingDITAOpenToolkit, false);
		var objInstallingonWindows = { label: "Installing on Windows", href:"installing/windows_installing.html", target:"contentwin" };
    var InstallingonWindows = new YAHOO.widget.TextNode(objInstallingonWindows, InstallingandupgradingDITAOpenToolkit, false);
			var objInstallingtheJDKonWindows = { label: "Installing the JDK on Windows", href:"installing/windows_installingjdk.html", target:"contentwin" };
    var InstallingtheJDKonWindows = new YAHOO.widget.TextNode(objInstallingtheJDKonWindows, InstallingonWindows, false);
			var objInstallingAntonWindows = { label: "Installing Ant on Windows", href:"installing/windows_installingant.html", target:"contentwin" };
    var InstallingAntonWindows = new YAHOO.widget.TextNode(objInstallingAntonWindows, InstallingonWindows, false);
			var objInstallingSAXONonWindows = { label: "Installing SAXON on Windows", href:"installing/windows_installingsaxon.html", target:"contentwin" };
    var InstallingSAXONonWindows = new YAHOO.widget.TextNode(objInstallingSAXONonWindows, InstallingonWindows, false);
			var objInstallingXalanonWindows = { label: "Installing Xalan on Windows", href:"installing/windows_installingxalan.html", target:"contentwin" };
    var InstallingXalanonWindows = new YAHOO.widget.TextNode(objInstallingXalanonWindows, InstallingonWindows, false);
			var objInstallingDitaOpenToolkitonWindows = { label: "Installing Dita Open Toolkit on Windows", href:"installing/windows_installingditaot.html", target:"contentwin" };
    var InstallingDitaOpenToolkitonWindows = new YAHOO.widget.TextNode(objInstallingDitaOpenToolkitonWindows, InstallingonWindows, false);
			var objOptionalInstallingHTMLHelponWindows = { label: "(Optional) Installing HTML Help on Windows", href:"installing/windows_installinghtmlhelp.html", target:"contentwin" };
    var OptionalInstallingHTMLHelponWindows = new YAHOO.widget.TextNode(objOptionalInstallingHTMLHelponWindows, InstallingonWindows, false);
			var objOptionalInstallingJavaHelponWindows = { label: "(Optional) Installing JavaHelp on Windows", href:"installing/windows_installingjavahelp.html", target:"contentwin" };
    var OptionalInstallingJavaHelponWindows = new YAHOO.widget.TextNode(objOptionalInstallingJavaHelponWindows, InstallingonWindows, false);
			var objOptionalInstallingFOPonWindows = { label: "(Optional) Installing FOP on Windows", href:"installing/windows_installingfop.html", target:"contentwin" };
    var OptionalInstallingFOPonWindows = new YAHOO.widget.TextNode(objOptionalInstallingFOPonWindows, InstallingonWindows, false);
			var objSettingenvironmentvariablesonWindows = { label: "Setting environment variables on Windows", href:"installing/windows_settingenvvariables.html", target:"contentwin" };
    var SettingenvironmentvariablesonWindows = new YAHOO.widget.TextNode(objSettingenvironmentvariablesonWindows, InstallingonWindows, false);
			var objVerifyingtheinstallationonWindows = { label: "Verifying the installation on Windows", href:"installing/windows_verifying.html", target:"contentwin" };
    var VerifyingtheinstallationonWindows = new YAHOO.widget.TextNode(objVerifyingtheinstallationonWindows, InstallingonWindows, false);
		
		var objInstallingonLinux = { label: "Installing on Linux", href:"installing/linux_installing.html", target:"contentwin" };
    var InstallingonLinux = new YAHOO.widget.TextNode(objInstallingonLinux, InstallingandupgradingDITAOpenToolkit, false);
			var objInstallingtheJDKonLinux = { label: "Installing the JDK on Linux", href:"installing/linux_installingjdk.html", target:"contentwin" };
    var InstallingtheJDKonLinux = new YAHOO.widget.TextNode(objInstallingtheJDKonLinux, InstallingonLinux, false);
			var objInstallingAntonLinux = { label: "Installing Ant on Linux", href:"installing/linux_installingant.html", target:"contentwin" };
    var InstallingAntonLinux = new YAHOO.widget.TextNode(objInstallingAntonLinux, InstallingonLinux, false);
			var objInstallingSAXONonLinux = { label: "Installing SAXON on Linux", href:"installing/linux_installingsaxon.html", target:"contentwin" };
    var InstallingSAXONonLinux = new YAHOO.widget.TextNode(objInstallingSAXONonLinux, InstallingonLinux, false);
			var objInstallingXalanonLinux = { label: "Installing Xalan on Linux", href:"installing/linux_installingxalan.html", target:"contentwin" };
    var InstallingXalanonLinux = new YAHOO.widget.TextNode(objInstallingXalanonLinux, InstallingonLinux, false);
			var objInstallingDITAOpenToolkitonLinux = { label: "Installing DITA Open Toolkit on Linux", href:"installing/linux_installingditaot.html", target:"contentwin" };
    var InstallingDITAOpenToolkitonLinux = new YAHOO.widget.TextNode(objInstallingDITAOpenToolkitonLinux, InstallingonLinux, false);
			var objOptionalInstallingJavaHelponLinux = { label: "(Optional) Installing JavaHelp on Linux", href:"installing/linux_installingjavahelp.html", target:"contentwin" };
    var OptionalInstallingJavaHelponLinux = new YAHOO.widget.TextNode(objOptionalInstallingJavaHelponLinux, InstallingonLinux, false);
			var objOptionalInstallingFOPonLinux = { label: "(Optional) Installing FOP on Linux", href:"installing/linux_installingfop.html", target:"contentwin" };
    var OptionalInstallingFOPonLinux = new YAHOO.widget.TextNode(objOptionalInstallingFOPonLinux, InstallingonLinux, false);
			var objSettingenvironmentvariablesonLinux = { label: "Setting environment variables on Linux", href:"installing/linux_settingenvvariables.html", target:"contentwin" };
    var SettingenvironmentvariablesonLinux = new YAHOO.widget.TextNode(objSettingenvironmentvariablesonLinux, InstallingonLinux, false);
			var objVerifyingtheinstallationonLinux = { label: "Verifying the installation on Linux", href:"installing/linux_verifying.html", target:"contentwin" };
    var VerifyingtheinstallationonLinux = new YAHOO.widget.TextNode(objVerifyingtheinstallationonLinux, InstallingonLinux, false);
		
		var objInstallingonMacOS = { label: "Installing on Mac OS", href:"installing/macos_installing.html", target:"contentwin" };
    var InstallingonMacOS = new YAHOO.widget.TextNode(objInstallingonMacOS, InstallingandupgradingDITAOpenToolkit, false);
			var objInstallingDITAOpenToolkitonMacOS = { label: "Installing DITA Open Toolkit on Mac OS", href:"installing/macos_installingditaot.html", target:"contentwin" };
    var InstallingDITAOpenToolkitonMacOS = new YAHOO.widget.TextNode(objInstallingDITAOpenToolkitonMacOS, InstallingonMacOS, false);
		
		var objDirectoriesandfilesintheditaotdirectory = { label: "Directories and files in the ditaot directory", href:"installing/ditaot_directory.html", target:"contentwin" };
    var Directoriesandfilesintheditaotdirectory = new YAHOO.widget.TextNode(objDirectoriesandfilesintheditaotdirectory, InstallingandupgradingDITAOpenToolkit, false);
		var objProductionnotesinstallingandupgrading = { label: "Production notes (installing and upgrading)", href:"installing/installing_production_notes.html", target:"contentwin" };
    var Productionnotesinstallingandupgrading = new YAHOO.widget.TextNode(objProductionnotesinstallingandupgrading, InstallingandupgradingDITAOpenToolkit, false);
		var objFormoreinformationinstallingandupgrading = { label: "For more information (installing and upgrading)", href:"installing/installing_formoreinfo.html", target:"contentwin" };
    var Formoreinformationinstallingandupgrading = new YAHOO.widget.TextNode(objFormoreinformationinstallingandupgrading, InstallingandupgradingDITAOpenToolkit, false);
	
	
	var objSettingupyourworkingenvironment = { label: "Setting up your working environment", href:"settingup/settingup.html", target:"contentwin" };
    var Settingupyourworkingenvironment = new YAHOO.widget.TextNode(objSettingupyourworkingenvironment, root, false);
		var objConfiguringyourauthoringtool = { label: "Configuring your authoring tool", href:"settingup/configuring_authoringtool.html", target:"contentwin" };
    var Configuringyourauthoringtool = new YAHOO.widget.TextNode(objConfiguringyourauthoringtool, Settingupyourworkingenvironment, false);
		var objSettingupyoursourceandoutputfiledirectories = { label: "Setting up your source and output file directories", href:"settingup/source_files.html", target:"contentwin" };
    var Settingupyoursourceandoutputfiledirectories = new YAHOO.widget.TextNode(objSettingupyoursourceandoutputfiledirectories, Settingupyourworkingenvironment, false);
		var objProductionnotessettingup = { label: "Production notes (setting up)", href:"settingup/settingup_production_notes.html", target:"contentwin" };
    var Productionnotessettingup = new YAHOO.widget.TextNode(objProductionnotessettingup, Settingupyourworkingenvironment, false);
		var objFormoreinformationsettingup = { label: "For more information (setting up)", href:"settingup/settingup_formoreinfo.html", target:"contentwin" };
    var Formoreinformationsettingup = new YAHOO.widget.TextNode(objFormoreinformationsettingup, Settingupyourworkingenvironment, false);
	
	
	var objProcessingbuildingandpublishingDITAdocuments = { label: "Processing (building) and publishing DITA documents", href:"processing/processing.html", target:"contentwin" };
    var ProcessingbuildingandpublishingDITAdocuments = new YAHOO.widget.TextNode(objProcessingbuildingandpublishingDITAdocuments, root, false);
		var objProcessingoverview = { label: "Processing overview", href:"processing/processing_overview.html", target:"contentwin" };
    var Processingoverview = new YAHOO.widget.TextNode(objProcessingoverview, ProcessingbuildingandpublishingDITAdocuments, false);
		var objAboutAnt = { label: "About Ant", href:"processing/aboutant.html", target:"contentwin" };
    var AboutAnt = new YAHOO.widget.TextNode(objAboutAnt, ProcessingbuildingandpublishingDITAdocuments, false);
		var objAboutAntscripts = { label: "About Ant scripts", href:"processing/aboutantscripts.html", target:"contentwin" };
    var AboutAntscripts = new YAHOO.widget.TextNode(objAboutAntscripts, ProcessingbuildingandpublishingDITAdocuments, false);
		var objAntprocessingparameters = { label: "Ant processing parameters", href:"processing/antparms.html", target:"contentwin" };
    var Antprocessingparameters = new YAHOO.widget.TextNode(objAntprocessingparameters, ProcessingbuildingandpublishingDITAdocuments, false);
		var objAboutthegaragesample = { label: "About the garage sample", href:"processing/aboutgarage_sample.html", target:"contentwin" };
    var Aboutthegaragesample = new YAHOO.widget.TextNode(objAboutthegaragesample, ProcessingbuildingandpublishingDITAdocuments, false);
		var objProcessingtoXHTMLtargets = { label: "Processing to XHTML targets", href:"processing/processing_xhtml.html", target:"contentwin" };
    var ProcessingtoXHTMLtargets = new YAHOO.widget.TextNode(objProcessingtoXHTMLtargets, ProcessingbuildingandpublishingDITAdocuments, false);
		var objProcessingtoHTMLHelptargets = { label: "Processing to HTML Help targets", href:"processing/processing_htmlhelp.html", target:"contentwin" };
    var ProcessingtoHTMLHelptargets = new YAHOO.widget.TextNode(objProcessingtoHTMLHelptargets, ProcessingbuildingandpublishingDITAdocuments, false);
		var objProcessingtoPDF2targets = { label: "Processing to PDF2 targets", href:"processing/processing_pdf2.html", target:"contentwin" };
    var ProcessingtoPDF2targets = new YAHOO.widget.TextNode(objProcessingtoPDF2targets, ProcessingbuildingandpublishingDITAdocuments, false);
		var objProcessingtoDocBooktargets = { label: "Processing to DocBook targets", href:"processing/processing_docbook.html", target:"contentwin" };
    var ProcessingtoDocBooktargets = new YAHOO.widget.TextNode(objProcessingtoDocBooktargets, ProcessingbuildingandpublishingDITAdocuments, false);
		var objProcessingtoEclipsecontenttargets = { label: "Processing to Eclipse content targets", href:"processing/processing_eclipsecontent.html", target:"contentwin" };
    var ProcessingtoEclipsecontenttargets = new YAHOO.widget.TextNode(objProcessingtoEclipsecontenttargets, ProcessingbuildingandpublishingDITAdocuments, false);
		var objProcessingtoEclipsehelptargets = { label: "Processing to Eclipse help targets", href:"processing/processing_eclipsehelp.html", target:"contentwin" };
    var ProcessingtoEclipsehelptargets = new YAHOO.widget.TextNode(objProcessingtoEclipsehelptargets, ProcessingbuildingandpublishingDITAdocuments, false);
		var objProcessingtoEclipsehelptargetsusingEclipse = { label: "Processing to Eclipse help targets using Eclipse", href:"processing/processing_PDEeclipsehelp.html", target:"contentwin" };
    var ProcessingtoEclipsehelptargetsusingEclipse = new YAHOO.widget.TextNode(objProcessingtoEclipsehelptargetsusingEclipse, ProcessingbuildingandpublishingDITAdocuments, false);
		var objProcessingtoJavaHelptargets = { label: "Processing to JavaHelp targets", href:"processing/processing_javahelp.html", target:"contentwin" };
    var ProcessingtoJavaHelptargets = new YAHOO.widget.TextNode(objProcessingtoJavaHelptargets, ProcessingbuildingandpublishingDITAdocuments, false);
		var objProcessingtotrofftargets = { label: "Processing to troff targets", href:"processing/processing_troff.html", target:"contentwin" };
    var Processingtotrofftargets = new YAHOO.widget.TextNode(objProcessingtotrofftargets, ProcessingbuildingandpublishingDITAdocuments, false);
		var objProcessingtoWordRTFtargets = { label: "Processing to Word RTF targets", href:"processing/processing_wordrtf.html", target:"contentwin" };
    var ProcessingtoWordRTFtargets = new YAHOO.widget.TextNode(objProcessingtoWordRTFtargets, ProcessingbuildingandpublishingDITAdocuments, false);
		var objProcessingfromtheJavacommandline = { label: "Processing from the Java command line", href:"processing/processing_javacmd.html", target:"contentwin" };
    var ProcessingfromtheJavacommandline = new YAHOO.widget.TextNode(objProcessingfromtheJavacommandline, ProcessingbuildingandpublishingDITAdocuments, false);
		var objProductionnotesprocessing = { label: "Production notes (processing)", href:"processing/processing_production_notes.html", target:"contentwin" };
    var Productionnotesprocessing = new YAHOO.widget.TextNode(objProductionnotesprocessing, ProcessingbuildingandpublishingDITAdocuments, false);
		var objFormoreinformationprocessing = { label: "For more information (processing)", href:"processing/processing_formoreinfo.html", target:"contentwin" };
    var Formoreinformationprocessing = new YAHOO.widget.TextNode(objFormoreinformationprocessing, ProcessingbuildingandpublishingDITAdocuments, false);
	
	
	var objTroubleshootingthebuildprocess = { label: "Troubleshooting the build process", href:"troubleshooting/troubleshooting.html", target:"contentwin" };
    var Troubleshootingthebuildprocess = new YAHOO.widget.TextNode(objTroubleshootingthebuildprocess, root, false);
		var objCapturingandusingthelog = { label: "Capturing and using the log", href:"troubleshooting/log.html", target:"contentwin" };
    var Capturingandusingthelog = new YAHOO.widget.TextNode(objCapturingandusingthelog, Troubleshootingthebuildprocess, false);
		var objDITAOpenToolkitErrorMessagesOverview = { label: "DITA Open Toolkit Error Messages Overview", href:"troubleshooting/messages_overview.html", target:"contentwin" };
    var DITAOpenToolkitErrorMessagesOverview = new YAHOO.widget.TextNode(objDITAOpenToolkitErrorMessagesOverview, Troubleshootingthebuildprocess, false);
		var objMessagesgeneratedbytheToolkit = { label: "Messages generated by the Toolkit", href:"troubleshooting/messages_toolkit.html", target:"contentwin" };
    var MessagesgeneratedbytheToolkit = new YAHOO.widget.TextNode(objMessagesgeneratedbytheToolkit, Troubleshootingthebuildprocess, false);
		var objMessagesgeneratedfromothersources = { label: "Messages generated from other sources", href:"troubleshooting/messages_other.html", target:"contentwin" };
    var Messagesgeneratedfromothersources = new YAHOO.widget.TextNode(objMessagesgeneratedfromothersources, Troubleshootingthebuildprocess, false);
		var objTroubleshootingCLASSPATHandenvironmentvariablessetup = { label: "Troubleshooting CLASSPATH and environment variables setup", href:"troubleshooting/classpath_environment.html", target:"contentwin" };
    var TroubleshootingCLASSPATHandenvironmentvariablessetup = new YAHOO.widget.TextNode(objTroubleshootingCLASSPATHandenvironmentvariablessetup, Troubleshootingthebuildprocess, false);
		var objAboutthedebuggingreportingandfilegenerationtools = { label: "About the debugging, reporting, and file generation tools", href:"troubleshooting/debuggingtools_overview.html", target:"contentwin" };
    var Aboutthedebuggingreportingandfilegenerationtools = new YAHOO.widget.TextNode(objAboutthedebuggingreportingandfilegenerationtools, Troubleshootingthebuildprocess, false);
		var objUsingthedebuggingandreportingtools = { label: "Using the debugging and reporting tools", href:"troubleshooting/debuggingtools_using.html", target:"contentwin" };
    var Usingthedebuggingandreportingtools = new YAHOO.widget.TextNode(objUsingthedebuggingandreportingtools, Troubleshootingthebuildprocess, false);
		var objProductionnotestroubleshooting = { label: "Production notes (troubleshooting)", href:"troubleshooting/troubleshooting_production_notes.html", target:"contentwin" };
    var Productionnotestroubleshooting = new YAHOO.widget.TextNode(objProductionnotestroubleshooting, Troubleshootingthebuildprocess, false);
		var objFormoreinformationtroubleshooting = { label: "For more information (troubleshooting)", href:"troubleshooting/troubleshooting_formoreinfo.html", target:"contentwin" };
    var Formoreinformationtroubleshooting = new YAHOO.widget.TextNode(objFormoreinformationtroubleshooting, Troubleshootingthebuildprocess, false);
	
	
	var objCreatingDITAtopics = { label: "Creating DITA topics", href:"topics/topics.html", target:"contentwin" };
    var CreatingDITAtopics = new YAHOO.widget.TextNode(objCreatingDITAtopics, root, false);
		var objAboutthegroceryshoppingsample = { label: "About the grocery shopping sample", href:"topics/aboutgroceryshopping_sample.html", target:"contentwin" };
    var Aboutthegroceryshoppingsample = new YAHOO.widget.TextNode(objAboutthegroceryshoppingsample, CreatingDITAtopics, false);
		var objAbouttopics = { label: "About topics", href:"topics/abouttopics.html", target:"contentwin" };
    var Abouttopics = new YAHOO.widget.TextNode(objAbouttopics, CreatingDITAtopics, false);
		var objCreatingtopics = { label: "Creating topics", href:"topics/creatingtopics.html", target:"contentwin" };
    var Creatingtopics = new YAHOO.widget.TextNode(objCreatingtopics, CreatingDITAtopics, false);
		var objAboutconcepts = { label: "About concepts", href:"topics/aboutconcepts.html", target:"contentwin" };
    var Aboutconcepts = new YAHOO.widget.TextNode(objAboutconcepts, CreatingDITAtopics, false);
		var objCreatingconcepts = { label: "Creating concepts", href:"topics/creatingconcepts.html", target:"contentwin" };
    var Creatingconcepts = new YAHOO.widget.TextNode(objCreatingconcepts, CreatingDITAtopics, false);
		var objAbouttasks = { label: "About tasks", href:"topics/abouttasks.html", target:"contentwin" };
    var Abouttasks = new YAHOO.widget.TextNode(objAbouttasks, CreatingDITAtopics, false);
		var objCreatingtasks = { label: "Creating tasks", href:"topics/creatingtasks.html", target:"contentwin" };
    var Creatingtasks = new YAHOO.widget.TextNode(objCreatingtasks, CreatingDITAtopics, false);
		var objAboutreferenceinformation = { label: "About reference information", href:"topics/aboutreference.html", target:"contentwin" };
    var Aboutreferenceinformation = new YAHOO.widget.TextNode(objAboutreferenceinformation, CreatingDITAtopics, false);
		var objCreatingreferencetopics = { label: "Creating reference topics", href:"topics/creatingreference.html", target:"contentwin" };
    var Creatingreferencetopics = new YAHOO.widget.TextNode(objCreatingreferencetopics, CreatingDITAtopics, false);
		var objProcessingbuildingasingletopic = { label: "Processing (building) a single topic", href:"topics/processing_singletopic.html", target:"contentwin" };
    var Processingbuildingasingletopic = new YAHOO.widget.TextNode(objProcessingbuildingasingletopic, CreatingDITAtopics, false);
		var objProductionnotestopics = { label: "Production notes (topics)", href:"topics/topics_production_notes.html", target:"contentwin" };
    var Productionnotestopics = new YAHOO.widget.TextNode(objProductionnotestopics, CreatingDITAtopics, false);
		var objFormoreinformationtopics = { label: "For more information (topics)", href:"topics/topics_formoreinfo.html", target:"contentwin" };
    var Formoreinformationtopics = new YAHOO.widget.TextNode(objFormoreinformationtopics, CreatingDITAtopics, false);
	
	
	var objCreatingDITAmaps = { label: "Creating DITA maps", href:"maps/maps.html", target:"contentwin" };
    var CreatingDITAmaps = new YAHOO.widget.TextNode(objCreatingDITAmaps, root, false);
		var objAboutmaps = { label: "About maps", href:"maps/aboutmaps.html", target:"contentwin" };
    var Aboutmaps = new YAHOO.widget.TextNode(objAboutmaps, CreatingDITAmaps, false);
		var objCreatingmaps = { label: "Creating maps", href:"maps/creatingmaps.html", target:"contentwin" };
    var Creatingmaps = new YAHOO.widget.TextNode(objCreatingmaps, CreatingDITAmaps, false);
		var objProcessingbuildingthegroceryshoppingsample = { label: "Processing (building) the grocery shopping sample", href:"maps/processing_groceryshopping.html", target:"contentwin" };
    var Processingbuildingthegroceryshoppingsample = new YAHOO.widget.TextNode(objProcessingbuildingthegroceryshoppingsample, CreatingDITAmaps, false);
		var objProductionnotesmaps = { label: "Production notes (maps)", href:"maps/maps_production_notes.html", target:"contentwin" };
    var Productionnotesmaps = new YAHOO.widget.TextNode(objProductionnotesmaps, CreatingDITAmaps, false);
		var objFormoreinformationmaps = { label: "For more information (maps)", href:"maps/maps_formoreinfo.html", target:"contentwin" };
    var Formoreinformationmaps = new YAHOO.widget.TextNode(objFormoreinformationmaps, CreatingDITAmaps, false);
	
	
	var objLinkingcontent = { label: "Linking content", href:"linking/linking.html", target:"contentwin" };
    var Linkingcontent = new YAHOO.widget.TextNode(objLinkingcontent, root, false);
		var objAboutlinking = { label: "About linking", href:"linking/aboutlinking.html", target:"contentwin" };
    var Aboutlinking = new YAHOO.widget.TextNode(objAboutlinking, Linkingcontent, false);
		var objLinkingusingcrossreferencesxrefs = { label: "Linking using cross-references (xrefs)", href:"linking/linking_xrefs.html", target:"contentwin" };
    var Linkingusingcrossreferencesxrefs = new YAHOO.widget.TextNode(objLinkingusingcrossreferencesxrefs, Linkingcontent, false);
		var objLinkingusingrelatedlinks = { label: "Linking using related links", href:"linking/related_links.html", target:"contentwin" };
    var Linkingusingrelatedlinks = new YAHOO.widget.TextNode(objLinkingusingrelatedlinks, Linkingcontent, false);
		var objLinkingusingrelationshiptables = { label: "Linking using relationship tables", href:"linking/relationship_tables.html", target:"contentwin" };
    var Linkingusingrelationshiptables = new YAHOO.widget.TextNode(objLinkingusingrelationshiptables, Linkingcontent, false);
		var objProductionnoteslinking = { label: "Production notes (linking)", href:"linking/linking_production_notes.html", target:"contentwin" };
    var Productionnoteslinking = new YAHOO.widget.TextNode(objProductionnoteslinking, Linkingcontent, false);
		var objFormoreinformationlinking = { label: "For more information (linking)", href:"linking/linking_formoreinfo.html", target:"contentwin" };
    var Formoreinformationlinking = new YAHOO.widget.TextNode(objFormoreinformationlinking, Linkingcontent, false);
	
	
	var objDITAOpenToolkitplugins = { label: "DITA Open Toolkit plug-ins", href:"plugins/plugins.html", target:"contentwin" };
    var DITAOpenToolkitplugins = new YAHOO.widget.TextNode(objDITAOpenToolkitplugins, root, false);
		var objAboutDITAOpenToolkitplugins = { label: "About DITA Open Toolkit plug-ins", href:"plugins/plugins_overview.html", target:"contentwin" };
    var AboutDITAOpenToolkitplugins = new YAHOO.widget.TextNode(objAboutDITAOpenToolkitplugins, DITAOpenToolkitplugins, false);
		var objInstallingplugins = { label: "Installing plug-ins", href:"plugins/installing_plugins.html", target:"contentwin" };
    var Installingplugins = new YAHOO.widget.TextNode(objInstallingplugins, DITAOpenToolkitplugins, false);
			var objGenericinstallationinstructionsforplugins = { label: "Generic installation instructions for plug-ins", href:"plugins/installing_generic.html", target:"contentwin" };
    var Genericinstallationinstructionsforplugins = new YAHOO.widget.TextNode(objGenericinstallationinstructionsforplugins, Installingplugins, false);
			var objInstallingtheIdiomFOplugin = { label: "Installing the Idiom FO plug-in", href:"plugins/installing_fo.html", target:"contentwin" };
    var InstallingtheIdiomFOplugin = new YAHOO.widget.TextNode(objInstallingtheIdiomFOplugin, Installingplugins, false);
			var objProductionnotesplugins = { label: "Production notes (plug-ins)", href:"plugins/plugins_production_notes.html", target:"contentwin" };
    var Productionnotesplugins = new YAHOO.widget.TextNode(objProductionnotesplugins, Installingplugins, false);
			var objFormoreinformationplugins = { label: "For more information (plug-ins)", href:"plugins/plugins_formoreinfo.html", target:"contentwin" };
    var Formoreinformationplugins = new YAHOO.widget.TextNode(objFormoreinformationplugins, Installingplugins, false);
		
	
	
	var objManagingyourcontent = { label: "Managing your content", href:"managing/managing.html", target:"contentwin" };
    var Managingyourcontent = new YAHOO.widget.TextNode(objManagingyourcontent, root, false);
		var objBackingupyoursourcefiles = { label: "Backing up your source files", href:"managing/backingup.html", target:"contentwin" };
    var Backingupyoursourcefiles = new YAHOO.widget.TextNode(objBackingupyoursourcefiles, Managingyourcontent, false);
		var objUsingalibraryorsourcecontrolsystem = { label: "Using a library or source control system", href:"managing/library_system.html", target:"contentwin" };
    var Usingalibraryorsourcecontrolsystem = new YAHOO.widget.TextNode(objUsingalibraryorsourcecontrolsystem, Managingyourcontent, false);
		var objUsingaacontentmanagementsystem = { label: "Using a a content management system", href:"managing/cms.html", target:"contentwin" };
    var Usingaacontentmanagementsystem = new YAHOO.widget.TextNode(objUsingaacontentmanagementsystem, Managingyourcontent, false);
		var objProductionnotesmanagingyourcontent = { label: "Production notes (managing your content)", href:"managing/managing_production_notes.html", target:"contentwin" };
    var Productionnotesmanagingyourcontent = new YAHOO.widget.TextNode(objProductionnotesmanagingyourcontent, Managingyourcontent, false);
		var objFormoreinformationmanagingcontent = { label: "For more information (managing content)", href:"managing/managing_formoreinfo.html", target:"contentwin" };
    var Formoreinformationmanagingcontent = new YAHOO.widget.TextNode(objFormoreinformationmanagingcontent, Managingyourcontent, false);
	
	
	var objReuseconceptsandtechniques = { label: "Reuse concepts and techniques", href:"reusing/reusing.html", target:"contentwin" };
    var Reuseconceptsandtechniques = new YAHOO.widget.TextNode(objReuseconceptsandtechniques, root, false);
		var objAboutreuse = { label: "About reuse", href:"reusing/aboutreuse.html", target:"contentwin" };
    var Aboutreuse = new YAHOO.widget.TextNode(objAboutreuse, Reuseconceptsandtechniques, false);
		var objSpecializationoverview = { label: "Specialization overview", href:"reusing/specialization_overview.html", target:"contentwin" };
    var Specializationoverview = new YAHOO.widget.TextNode(objSpecializationoverview, Reuseconceptsandtechniques, false);
		var objImplementingprocessingreuse = { label: "Implementing processing reuse", href:"reusing/implementingprocessing_reuse.html", target:"contentwin" };
    var Implementingprocessingreuse = new YAHOO.widget.TextNode(objImplementingprocessingreuse, Reuseconceptsandtechniques, false);
		var objProductionnotesreuseconceptsandtechniques = { label: "Production notes (reuse concepts and techniques)", href:"reusing/reusing_production_notes.html", target:"contentwin" };
    var Productionnotesreuseconceptsandtechniques = new YAHOO.widget.TextNode(objProductionnotesreuseconceptsandtechniques, Reuseconceptsandtechniques, false);
		var objFormoreinformationreuse = { label: "For more information (reuse)", href:"reusing/reusing_formoreinfo.html", target:"contentwin" };
    var Formoreinformationreuse = new YAHOO.widget.TextNode(objFormoreinformationreuse, Reuseconceptsandtechniques, false);
	
	
	var objExpandingandcustomizingaccesstoyourinformation = { label: "Expanding and customizing access to your information", href:"accessing/accessing.html", target:"contentwin" };
    var Expandingandcustomizingaccesstoyourinformation = new YAHOO.widget.TextNode(objExpandingandcustomizingaccesstoyourinformation, root, false);
		var objAboutindexing = { label: "About indexing", href:"accessing/aboutindexing.html", target:"contentwin" };
    var Aboutindexing = new YAHOO.widget.TextNode(objAboutindexing, Expandingandcustomizingaccesstoyourinformation, false);
		var objAboutmetadata = { label: "About metadata", href:"accessing/aboutmetadata.html", target:"contentwin" };
    var Aboutmetadata = new YAHOO.widget.TextNode(objAboutmetadata, Expandingandcustomizingaccesstoyourinformation, false);
		var objAboutRDFandtheDITAOpenToolkit = { label: "About RDF and the DITA Open Toolkit", href:"accessing/aboutrdfowl.html", target:"contentwin" };
    var AboutRDFandtheDITAOpenToolkit = new YAHOO.widget.TextNode(objAboutRDFandtheDITAOpenToolkit, Expandingandcustomizingaccesstoyourinformation, false);
		var objAboutfilteringconditionalprocessing = { label: "About filtering (conditional processing)", href:"accessing/aboutfiltering.html", target:"contentwin" };
    var Aboutfilteringconditionalprocessing = new YAHOO.widget.TextNode(objAboutfilteringconditionalprocessing, Expandingandcustomizingaccesstoyourinformation, false);
		var objProductionnotesaccessing = { label: "Production notes (accessing)", href:"accessing/accessing_production_notes.html", target:"contentwin" };
    var Productionnotesaccessing = new YAHOO.widget.TextNode(objProductionnotesaccessing, Expandingandcustomizingaccesstoyourinformation, false);
		var objFormoreinformationaccessing = { label: "For more information (accessing)", href:"accessing/accessing_formoreinfo.html", target:"contentwin" };
    var Formoreinformationaccessing = new YAHOO.widget.TextNode(objFormoreinformationaccessing, Expandingandcustomizingaccesstoyourinformation, false);
	
	
	var objCustomizingyourpublishedoutput = { label: "Customizing your published output", href:"customizing/customizing.html", target:"contentwin" };
    var Customizingyourpublishedoutput = new YAHOO.widget.TextNode(objCustomizingyourpublishedoutput, root, false);
		var objUsingyourownCSScascadingstylesheet = { label: "Using your own CSS (cascading style sheet)", href:"customizing/css.html", target:"contentwin" };
    var UsingyourownCSScascadingstylesheet = new YAHOO.widget.TextNode(objUsingyourownCSScascadingstylesheet, Customizingyourpublishedoutput, false);
		var objTailoringXHTMLoutput = { label: "Tailoring XHTML output", href:"customizing/tailoring_xhtml.html", target:"contentwin" };
    var TailoringXHTMLoutput = new YAHOO.widget.TextNode(objTailoringXHTMLoutput, Customizingyourpublishedoutput, false);
		var objProductionnotes = { label: "Production notes", href:"customizing/customizing_production_notes.html", target:"contentwin" };
    var Productionnotes = new YAHOO.widget.TextNode(objProductionnotes, Customizingyourpublishedoutput, false);
		var objFormoreinformationcustomizing = { label: "For more information (customizing)", href:"customizing/customizing_formoreinfo.html", target:"contentwin" };
    var Formoreinformationcustomizing = new YAHOO.widget.TextNode(objFormoreinformationcustomizing, Customizingyourpublishedoutput, false);
	
	
	var objLocalizingtranslatingyourDITAcontent = { label: "Localizing (translating) your DITA content", href:"localizing/localizing.html", target:"contentwin" };
    var LocalizingtranslatingyourDITAcontent = new YAHOO.widget.TextNode(objLocalizingtranslatingyourDITAcontent, root, false);
		var objAboutlocalizingtranslating = { label: "About localizing (translating)", href:"localizing/aboutlocalizing.html", target:"contentwin" };
    var Aboutlocalizingtranslating = new YAHOO.widget.TextNode(objAboutlocalizingtranslating, LocalizingtranslatingyourDITAcontent, false);
		var objProductionnoteslocalizing = { label: "Production notes (localizing)", href:"localizing/localizing_production_notes.html", target:"contentwin" };
    var Productionnoteslocalizing = new YAHOO.widget.TextNode(objProductionnoteslocalizing, LocalizingtranslatingyourDITAcontent, false);
		var objFormoreinformationlocalizing = { label: "For more information (localizing)", href:"localizing/localizing_formoreinfo.html", target:"contentwin" };
    var Formoreinformationlocalizing = new YAHOO.widget.TextNode(objFormoreinformationlocalizing, LocalizingtranslatingyourDITAcontent, false);
	
	
	var objDistributingyourpublishedcontent = { label: "Distributing your published content", href:"distributing/distributing.html", target:"contentwin" };
    var Distributingyourpublishedcontent = new YAHOO.widget.TextNode(objDistributingyourpublishedcontent, root, false);
		var objAboutdistributingcontent = { label: "About distributing content", href:"distributing/aboutdistributing.html", target:"contentwin" };
    var Aboutdistributingcontent = new YAHOO.widget.TextNode(objAboutdistributingcontent, Distributingyourpublishedcontent, false);
		var objDistributinginformationaboutpublishedDITAcontentasRSS = { label: "Distributing information about published DITA content as RSS", href:"distributing/rss_overview.html", target:"contentwin" };
    var DistributinginformationaboutpublishedDITAcontentasRSS = new YAHOO.widget.TextNode(objDistributinginformationaboutpublishedDITAcontentasRSS, Distributingyourpublishedcontent, false);
		var objDistributinginformationbypublishingDITAcontentonawebserver = { label: "Distributing information by publishing DITA content on a web server", href:"distributing/server.html", target:"contentwin" };
    var DistributinginformationbypublishingDITAcontentonawebserver = new YAHOO.widget.TextNode(objDistributinginformationbypublishingDITAcontentonawebserver, Distributingyourpublishedcontent, false);
		var objProductionnotesdistributing = { label: "Production notes (distributing)", href:"distributing/distributing_production_notes.html", target:"contentwin" };
    var Productionnotesdistributing = new YAHOO.widget.TextNode(objProductionnotesdistributing, Distributingyourpublishedcontent, false);
		var objFormoreinformationdistributing = { label: "For more information (distributing)", href:"distributing/distributing_formoreinfo.html", target:"contentwin" };
    var Formoreinformationdistributing = new YAHOO.widget.TextNode(objFormoreinformationdistributing, Distributingyourpublishedcontent, false);
	
	
	var objMigratinglegacycontenttoDITA = { label: "Migrating legacy content to DITA", href:"migratingcontent/migratingcontent.html", target:"contentwin" };
    var MigratinglegacycontenttoDITA = new YAHOO.widget.TextNode(objMigratinglegacycontenttoDITA, root, false);
	    var objContentmigrationoverview = { label: "Content migration overview", href:"migratingcontent/migratingcontent_overview.html", target:"contentwin" };
    var Contentmigrationoverview = new YAHOO.widget.TextNode(objContentmigrationoverview, MigratinglegacycontenttoDITA, false);
		var objProductionnotesmigratingcontent = { label: "Production notes (migrating content)", href:"migratingcontent/migratingcontent_production_notes.html", target:"contentwin" };
    var Productionnotesmigratingcontent = new YAHOO.widget.TextNode(objProductionnotesmigratingcontent, MigratinglegacycontenttoDITA, false);
		var objFormoreinformationmigratingcontent = { label: "For more information (migrating content)", href:"migratingcontent/migratingcontent_formoreinfo.html", target:"contentwin" };
    var Formoreinformationmigratingcontent = new YAHOO.widget.TextNode(objFormoreinformationmigratingcontent, MigratinglegacycontenttoDITA, false);
	
	
	var objSamplefiles = { label: "Sample files", href:"samples/samples.html", target:"contentwin" };
    var Samplefiles = new YAHOO.widget.TextNode(objSamplefiles, root, false);
	
	
	var objFrequentlyaskedquestionsFAQs = { label: "Frequently asked questions (FAQs)", href:"faqs/faqs.html", target:"contentwin" };
    var FrequentlyaskedquestionsFAQs = new YAHOO.widget.TextNode(objFrequentlyaskedquestionsFAQs, root, false);
		var objWhatis"Darwin"inthenameoftheDITAarchitectureandDITAOpenToolkit? = { label: "What is "Darwin" in the name of the DITA architecture and DITA Open Toolkit?", href:"faqs/darwin_name.html", target:"contentwin" };
    var Whatis"Darwin"inthenameoftheDITAarchitectureandDITAOpenToolkit? = new YAHOO.widget.TextNode(objWhatis"Darwin"inthenameoftheDITAarchitectureandDITAOpenToolkit?, FrequentlyaskedquestionsFAQs, false);
		var objWhatistheideallengthforaDITAtopic? = { label: "What is the ideal length for a DITA topic?", href:"faqs/topic_length.html", target:"contentwin" };
    var WhatistheideallengthforaDITAtopic? = new YAHOO.widget.TextNode(objWhatistheideallengthforaDITAtopic?, FrequentlyaskedquestionsFAQs, false);
		var objDoIneedtoknowXMLtouseDITA? = { label: "Do I need to know XML to use DITA?", href:"faqs/xml.html", target:"contentwin" };
    var DoIneedtoknowXMLtouseDITA? = new YAHOO.widget.TextNode(objDoIneedtoknowXMLtouseDITA?, FrequentlyaskedquestionsFAQs, false);
		var objHowdoesDITAdifferfromDocBook? = { label: "How does DITA differ from DocBook?", href:"faqs/dita_docbook.html", target:"contentwin" };
    var HowdoesDITAdifferfromDocBook? = new YAHOO.widget.TextNode(objHowdoesDITAdifferfromDocBook?, FrequentlyaskedquestionsFAQs, false);
	
	
	var objDITAcorevocabulary = { label: "DITA core vocabulary", href:"core_vocabulary/core_vocabulary.html", target:"contentwin" };
    var DITAcorevocabulary = new YAHOO.widget.TextNode(objDITAcorevocabulary, root, false);
		var objAbouttheDITAcorevocabulary = { label: "About the DITA core vocabulary", href:"core_vocabulary/aboutditacore.html", target:"contentwin" };
    var AbouttheDITAcorevocabulary = new YAHOO.widget.TextNode(objAbouttheDITAcorevocabulary, DITAcorevocabulary, false);
		var objAdministratorormanageraudiencecategory = { label: "Administrator or manager audience category", href:"core_vocabulary/administrator_manager.html", target:"contentwin" };
    var Administratorormanageraudiencecategory = new YAHOO.widget.TextNode(objAdministratorormanageraudiencecategory, DITAcorevocabulary, false);
		var objAnt = { label: "Ant", href:"core_vocabulary/ant.html", target:"contentwin" };
    var Ant = new YAHOO.widget.TextNode(objAnt, DITAcorevocabulary, false);
		var objAntscripts = { label: "Ant scripts", href:"core_vocabulary/antscripts.html", target:"contentwin" };
    var Antscripts = new YAHOO.widget.TextNode(objAntscripts, DITAcorevocabulary, false);
		var objAudience = { label: "Audience", href:"core_vocabulary/audience.html", target:"contentwin" };
    var Audience = new YAHOO.widget.TextNode(objAudience, DITAcorevocabulary, false);
		var objBestpractices = { label: "Best practices", href:"core_vocabulary/best_practices.html", target:"contentwin" };
    var Bestpractices = new YAHOO.widget.TextNode(objBestpractices, DITAcorevocabulary, false);
		var objBlockelement = { label: "Block element", href:"core_vocabulary/block_element.html", target:"contentwin" };
    var Blockelement = new YAHOO.widget.TextNode(objBlockelement, DITAcorevocabulary, false);
		var objBodyelementbody = { label: "Body element (<body>)", href:"core_vocabulary/body_element.html", target:"contentwin" };
    var Bodyelementbody = new YAHOO.widget.TextNode(objBodyelementbody, DITAcorevocabulary, false);
		var objBuildfile = { label: "Build file", href:"core_vocabulary/build_file.html", target:"contentwin" };
    var Buildfile = new YAHOO.widget.TextNode(objBuildfile, DITAcorevocabulary, false);
		var objCascadingstylesheetCSS = { label: "Cascading stylesheet (CSS)", href:"core_vocabulary/cascading_stylesheet.html", target:"contentwin" };
    var CascadingstylesheetCSS = new YAHOO.widget.TextNode(objCascadingstylesheetCSS, DITAcorevocabulary, false);
		var objChoicetable = { label: "Choice table", href:"core_vocabulary/choice_table.html", target:"contentwin" };
    var Choicetable = new YAHOO.widget.TextNode(objChoicetable, DITAcorevocabulary, false);
		var objCollectiontypeattribute = { label: "Collection-type attribute", href:"core_vocabulary/collectiontype_attribute.html", target:"contentwin" };
    var Collectiontypeattribute = new YAHOO.widget.TextNode(objCollectiontypeattribute, DITAcorevocabulary, false);
		var objCommandelementcmd = { label: "Command element (<cmd>)", href:"core_vocabulary/command_element.html", target:"contentwin" };
    var Commandelementcmd = new YAHOO.widget.TextNode(objCommandelementcmd, DITAcorevocabulary, false);
		var objConcept = { label: "Concept", href:"core_vocabulary/concept.html", target:"contentwin" };
    var Concept = new YAHOO.widget.TextNode(objConcept, DITAcorevocabulary, false);
		var objConceptanalysis = { label: "Concept analysis", href:"core_vocabulary/concept_analysis.html", target:"contentwin" };
    var Conceptanalysis = new YAHOO.widget.TextNode(objConceptanalysis, DITAcorevocabulary, false);
		var objConceptinformationtype = { label: "Concept information type", href:"core_vocabulary/concept_infotype.html", target:"contentwin" };
    var Conceptinformationtype = new YAHOO.widget.TextNode(objConceptinformationtype, DITAcorevocabulary, false);
		var objConditionalprocessing = { label: "Conditional processing", href:"core_vocabulary/conditional_processing.html", target:"contentwin" };
    var Conditionalprocessing = new YAHOO.widget.TextNode(objConditionalprocessing, DITAcorevocabulary, false);
		var objContent = { label: "Content", href:"core_vocabulary/content.html", target:"contentwin" };
    var Content = new YAHOO.widget.TextNode(objContent, DITAcorevocabulary, false);
		var objContentinventory = { label: "Content inventory", href:"core_vocabulary/content_inventory.html", target:"contentwin" };
    var Contentinventory = new YAHOO.widget.TextNode(objContentinventory, DITAcorevocabulary, false);
		var objContentreferenceattribute = { label: "Content reference attribute", href:"core_vocabulary/contentref_attribute.html", target:"contentwin" };
    var Contentreferenceattribute = new YAHOO.widget.TextNode(objContentreferenceattribute, DITAcorevocabulary, false);
		var objContentreuse = { label: "Content reuse", href:"core_vocabulary/content_reuse.html", target:"contentwin" };
    var Contentreuse = new YAHOO.widget.TextNode(objContentreuse, DITAcorevocabulary, false);
		var objContentspecialistaudiencecategory = { label: "Content specialist audience category", href:"core_vocabulary/content_specialist.html", target:"contentwin" };
    var Contentspecialistaudiencecategory = new YAHOO.widget.TextNode(objContentspecialistaudiencecategory, DITAcorevocabulary, false);
		var objContentreferenceattribute = { label: "Content reference attribute", href:"core_vocabulary/contentref_attribute.html", target:"contentwin" };
    var Contentreferenceattribute = new YAHOO.widget.TextNode(objContentreferenceattribute, DITAcorevocabulary, false);
		var objContextelementcontext = { label: "Context element (<context>)", href:"core_vocabulary/context_element.html", target:"contentwin" };
    var Contextelementcontext = new YAHOO.widget.TextNode(objContextelementcontext, DITAcorevocabulary, false);
		var objControlledvocabulary = { label: "Controlled vocabulary", href:"core_vocabulary/controlled_vocabulary.html", target:"contentwin" };
    var Controlledvocabulary = new YAHOO.widget.TextNode(objControlledvocabulary, DITAcorevocabulary, false);
		var objCrossreferenceelementxref = { label: "Cross-reference element (<xref>)", href:"core_vocabulary/crossreference_element.html", target:"contentwin" };
    var Crossreferenceelementxref = new YAHOO.widget.TextNode(objCrossreferenceelementxref, DITAcorevocabulary, false);
		var objDarwinInformationTypingArchitectureDITA = { label: "Darwin Information Typing Architecture (DITA)", href:"core_vocabulary/darwininfo_typingarch.html", target:"contentwin" };
    var DarwinInformationTypingArchitectureDITA = new YAHOO.widget.TextNode(objDarwinInformationTypingArchitectureDITA, DITAcorevocabulary, false);
		var objDefinitionlist = { label: "Definition list", href:"core_vocabulary/definition_list.html", target:"contentwin" };
    var Definitionlist = new YAHOO.widget.TextNode(objDefinitionlist, DITAcorevocabulary, false);
		var objDistributingyourpublishedcontent = { label: "Distributing your published content", href:"core_vocabulary/distributing_content.html", target:"contentwin" };
    var Distributingyourpublishedcontent = new YAHOO.widget.TextNode(objDistributingyourpublishedcontent, DITAcorevocabulary, false);
		var objDITA = { label: "DITA", href:"core_vocabulary/ditaterm.html", target:"contentwin" };
    var DITA = new YAHOO.widget.TextNode(objDITA, DITAcorevocabulary, false);
		var objDITAOpenToolkitOT = { label: "DITA Open Toolkit (OT)", href:"core_vocabulary/ditaot.html", target:"contentwin" };
    var DITAOpenToolkitOT = new YAHOO.widget.TextNode(objDITAOpenToolkitOT, DITAcorevocabulary, false);
		var objDITAOpenToolkitUserGuideandReference = { label: "DITA Open Toolkit User Guide and Reference", href:"core_vocabulary/ditaotugref.html", target:"contentwin" };
    var DITAOpenToolkitUserGuideandReference = new YAHOO.widget.TextNode(objDITAOpenToolkitUserGuideandReference, DITAcorevocabulary, false);
		var objDocBook = { label: "DocBook", href:"core_vocabulary/docbook.html", target:"contentwin" };
    var DocBook = new YAHOO.widget.TextNode(objDocBook, DITAcorevocabulary, false);
		var objDOCTYPEdeclaration = { label: "DOCTYPE declaration", href:"core_vocabulary/doctype_declaration.html", target:"contentwin" };
    var DOCTYPEdeclaration = new YAHOO.widget.TextNode(objDOCTYPEdeclaration, DITAcorevocabulary, false);
		var objDocumenttypedefinitionDTD = { label: "Document type definition (DTD)", href:"core_vocabulary/document_typedef.html", target:"contentwin" };
    var DocumenttypedefinitionDTD = new YAHOO.widget.TextNode(objDocumenttypedefinitionDTD, DITAcorevocabulary, false);
		var objDomainelement = { label: "Domain element", href:"core_vocabulary/domain_element.html", target:"contentwin" };
    var Domainelement = new YAHOO.widget.TextNode(objDomainelement, DITAcorevocabulary, false);
		var objEclipsecontent = { label: "Eclipse content", href:"core_vocabulary/eclipse_content.html", target:"contentwin" };
    var Eclipsecontent = new YAHOO.widget.TextNode(objEclipsecontent, DITAcorevocabulary, false);
		var objEclipsehelp = { label: "Eclipse help", href:"core_vocabulary/eclipse_help.html", target:"contentwin" };
    var Eclipsehelp = new YAHOO.widget.TextNode(objEclipsehelp, DITAcorevocabulary, false);
		var objEditor = { label: "Editor", href:"core_vocabulary/editor.html", target:"contentwin" };
    var Editor = new YAHOO.widget.TextNode(objEditor, DITAcorevocabulary, false);
		var objEnvironmentvariable = { label: "Environment variable", href:"core_vocabulary/environment_variable.html", target:"contentwin" };
    var Environmentvariable = new YAHOO.widget.TextNode(objEnvironmentvariable, DITAcorevocabulary, false);
		var objExampleelementexample = { label: "Example element (<example>)", href:"core_vocabulary/example_element.html", target:"contentwin" };
    var Exampleelementexample = new YAHOO.widget.TextNode(objExampleelementexample, DITAcorevocabulary, false);
		var objFamilylinking = { label: "Family linking", href:"core_vocabulary/family_linking.html", target:"contentwin" };
    var Familylinking = new YAHOO.widget.TextNode(objFamilylinking, DITAcorevocabulary, false);
		var objFigureelementfig = { label: "Figure element (<fig>)", href:"core_vocabulary/figure_element.html", target:"contentwin" };
    var Figureelementfig = new YAHOO.widget.TextNode(objFigureelementfig, DITAcorevocabulary, false);
		var objFilteringconditionalprocessing = { label: "Filtering (conditional processing)", href:"core_vocabulary/filtering.html", target:"contentwin" };
    var Filteringconditionalprocessing = new YAHOO.widget.TextNode(objFilteringconditionalprocessing, DITAcorevocabulary, false);
		var objFOPprocessor = { label: "FOP processor", href:"core_vocabulary/fop_processor.html", target:"contentwin" };
    var FOPprocessor = new YAHOO.widget.TextNode(objFOPprocessor, DITAcorevocabulary, false);
		var objFormatattribute = { label: "Format attribute", href:"core_vocabulary/format_attribute.html", target:"contentwin" };
    var Formatattribute = new YAHOO.widget.TextNode(objFormatattribute, DITAcorevocabulary, false);
		var objGaragesample = { label: "Garage sample", href:"core_vocabulary/garage_sample.html", target:"contentwin" };
    var Garagesample = new YAHOO.widget.TextNode(objGaragesample, DITAcorevocabulary, false);
		var objGroceryshoppingsample = { label: "Grocery shopping sample", href:"core_vocabulary/groceryshopping_sample.html", target:"contentwin" };
    var Groceryshoppingsample = new YAHOO.widget.TextNode(objGroceryshoppingsample, DITAcorevocabulary, false);
		var objGraphicdesigner = { label: "Graphic designer", href:"core_vocabulary/graphic_designer.html", target:"contentwin" };
    var Graphicdesigner = new YAHOO.widget.TextNode(objGraphicdesigner, DITAcorevocabulary, false);
		var objGuidelines = { label: "Guidelines", href:"core_vocabulary/guidelines.html", target:"contentwin" };
    var Guidelines = new YAHOO.widget.TextNode(objGuidelines, DITAcorevocabulary, false);
		var objHoverhelp = { label: "Hover help", href:"core_vocabulary/hoverhelp.html", target:"contentwin" };
    var Hoverhelp = new YAHOO.widget.TextNode(objHoverhelp, DITAcorevocabulary, false);
		var objHTMLHelp = { label: "HTML Help", href:"core_vocabulary/htmlhelp.html", target:"contentwin" };
    var HTMLHelp = new YAHOO.widget.TextNode(objHTMLHelp, DITAcorevocabulary, false);
		var objHTMLHelpcompiler = { label: "HTML Help compiler", href:"core_vocabulary/htmlhelp_compiler.html", target:"contentwin" };
    var HTMLHelpcompiler = new YAHOO.widget.TextNode(objHTMLHelpcompiler, DITAcorevocabulary, false);
		var objIDattribute = { label: "ID attribute", href:"core_vocabulary/id_attribute.html", target:"contentwin" };
    var IDattribute = new YAHOO.widget.TextNode(objIDattribute, DITAcorevocabulary, false);
		var objIndexingcontent = { label: "Indexing content", href:"core_vocabulary/indexing.html", target:"contentwin" };
    var Indexingcontent = new YAHOO.widget.TextNode(objIndexingcontent, DITAcorevocabulary, false);
		var objInformationanalysis = { label: "Information analysis", href:"core_vocabulary/information_analysis.html", target:"contentwin" };
    var Informationanalysis = new YAHOO.widget.TextNode(objInformationanalysis, DITAcorevocabulary, false);
		var objInformationarchitect = { label: "Information architect", href:"core_vocabulary/information_architect.html", target:"contentwin" };
    var Informationarchitect = new YAHOO.widget.TextNode(objInformationarchitect, DITAcorevocabulary, false);
		var objInformationdeveloper = { label: "Information developer", href:"core_vocabulary/information_developer.html", target:"contentwin" };
    var Informationdeveloper = new YAHOO.widget.TextNode(objInformationdeveloper, DITAcorevocabulary, false);
		var objInformationelementinfo = { label: "Information element (<info>)", href:"core_vocabulary/information_element.html", target:"contentwin" };
    var Informationelementinfo = new YAHOO.widget.TextNode(objInformationelementinfo, DITAcorevocabulary, false);
		var objInformationtype = { label: "Information type", href:"core_vocabulary/information_type.html", target:"contentwin" };
    var Informationtype = new YAHOO.widget.TextNode(objInformationtype, DITAcorevocabulary, false);
		var objInheritance = { label: "Inheritance", href:"core_vocabulary/inheritance.html", target:"contentwin" };
    var Inheritance = new YAHOO.widget.TextNode(objInheritance, DITAcorevocabulary, false);
		var objJavaDevelopmentKitJDK = { label: "Java Development Kit (JDK)", href:"core_vocabulary/jdk.html", target:"contentwin" };
    var JavaDevelopmentKitJDK = new YAHOO.widget.TextNode(objJavaDevelopmentKitJDK, DITAcorevocabulary, false);
		var objJavaHelp = { label: "JavaHelp", href:"core_vocabulary/javahelp.html", target:"contentwin" };
    var JavaHelp = new YAHOO.widget.TextNode(objJavaHelp, DITAcorevocabulary, false);
		var objJavaHelpprocessor = { label: "JavaHelp processor", href:"core_vocabulary/javahelp_processor.html", target:"contentwin" };
    var JavaHelpprocessor = new YAHOO.widget.TextNode(objJavaHelpprocessor, DITAcorevocabulary, false);
		var objKeywordelementkeyword = { label: "Keyword element (<keyword>)", href:"core_vocabulary/keyword_element.html", target:"contentwin" };
    var Keywordelementkeyword = new YAHOO.widget.TextNode(objKeywordelementkeyword, DITAcorevocabulary, false);
		var objLinkingattribute = { label: "Linking attribute", href:"core_vocabulary/linking_attribute.html", target:"contentwin" };
    var Linkingattribute = new YAHOO.widget.TextNode(objLinkingattribute, DITAcorevocabulary, false);
		var objLinkingcontent = { label: "Linking content", href:"core_vocabulary/linking_content.html", target:"contentwin" };
    var Linkingcontent = new YAHOO.widget.TextNode(objLinkingcontent, DITAcorevocabulary, false);
		var objMap = { label: "Map", href:"core_vocabulary/map.html", target:"contentwin" };
    var Map = new YAHOO.widget.TextNode(objMap, DITAcorevocabulary, false);
		var objMetadata = { label: "Metadata", href:"core_vocabulary/metadata.html", target:"contentwin" };
    var Metadata = new YAHOO.widget.TextNode(objMetadata, DITAcorevocabulary, false);
		var objMigratinglegacycontenttoDITA = { label: "Migrating legacy content to DITA", href:"core_vocabulary/migrating_content.html", target:"contentwin" };
    var MigratinglegacycontenttoDITA = new YAHOO.widget.TextNode(objMigratinglegacycontenttoDITA, DITAcorevocabulary, false);
		var objNavigationtitlenavtitle = { label: "Navigation title (<navtitle>)", href:"core_vocabulary/navigation_title.html", target:"contentwin" };
    var Navigationtitlenavtitle = new YAHOO.widget.TextNode(objNavigationtitlenavtitle, DITAcorevocabulary, false);
		var objOASISOrganizationfortheAdvancementofStructuredInformationStandards = { label: "OASIS (Organization for the Advancement of Structured Information Standards)", href:"core_vocabulary/oasis.html", target:"contentwin" };
    var OASISOrganizationfortheAdvancementofStructuredInformationStandards = new YAHOO.widget.TextNode(objOASISOrganizationfortheAdvancementofStructuredInformationStandards, DITAcorevocabulary, false);
		var objOrderedlist = { label: "Ordered list", href:"core_vocabulary/ordered_list.html", target:"contentwin" };
    var Orderedlist = new YAHOO.widget.TextNode(objOrderedlist, DITAcorevocabulary, false);
		var objPDFPortableDocumentFormat = { label: "PDF (Portable Document Format)", href:"core_vocabulary/pdf.html", target:"contentwin" };
    var PDFPortableDocumentFormat = new YAHOO.widget.TextNode(objPDFPortableDocumentFormat, DITAcorevocabulary, false);
		var objPhraseelements = { label: "Phrase elements", href:"core_vocabulary/phrase_elements.html", target:"contentwin" };
    var Phraseelements = new YAHOO.widget.TextNode(objPhraseelements, DITAcorevocabulary, false);
		var objPlugin = { label: "Plug-in", href:"core_vocabulary/plugin.html", target:"contentwin" };
    var Plugin = new YAHOO.widget.TextNode(objPlugin, DITAcorevocabulary, false);
		var objPostrequirementelementpostreq = { label: "Post-requirement element (<postreq>)", href:"core_vocabulary/post_requirement_element.html", target:"contentwin" };
    var Postrequirementelementpostreq = new YAHOO.widget.TextNode(objPostrequirementelementpostreq, DITAcorevocabulary, false);
		var objPrerequisiteelementprereq = { label: "Prerequisite element (<prereq>)", href:"core_vocabulary/prerequisite_element.html", target:"contentwin" };
    var Prerequisiteelementprereq = new YAHOO.widget.TextNode(objPrerequisiteelementprereq, DITAcorevocabulary, false);
		var objPrintdocumentdesigner = { label: "Print-document designer", href:"core_vocabulary/print_document_designer.html", target:"contentwin" };
    var Printdocumentdesigner = new YAHOO.widget.TextNode(objPrintdocumentdesigner, DITAcorevocabulary, false);
		var objProcessingbuilding = { label: "Processing (building)", href:"core_vocabulary/processing_building.html", target:"contentwin" };
    var Processingbuilding = new YAHOO.widget.TextNode(objProcessingbuilding, DITAcorevocabulary, false);
		var objProcessingattribute = { label: "Processing attribute", href:"core_vocabulary/processing_attribute.html", target:"contentwin" };
    var Processingattribute = new YAHOO.widget.TextNode(objProcessingattribute, DITAcorevocabulary, false);
		var objProcessingreuse = { label: "Processing reuse", href:"core_vocabulary/processing_reuse.html", target:"contentwin" };
    var Processingreuse = new YAHOO.widget.TextNode(objProcessingreuse, DITAcorevocabulary, false);
		var objProjectmanager = { label: "Project manager", href:"core_vocabulary/project_manager.html", target:"contentwin" };
    var Projectmanager = new YAHOO.widget.TextNode(objProjectmanager, DITAcorevocabulary, false);
		var objPrologelementprolog = { label: "Prolog element (<prolog>)", href:"core_vocabulary/prolog_element.html", target:"contentwin" };
    var Prologelementprolog = new YAHOO.widget.TextNode(objPrologelementprolog, DITAcorevocabulary, false);
		var objRDFOWL = { label: "RDF/OWL", href:"core_vocabulary/rdfowl.html", target:"contentwin" };
    var RDFOWL = new YAHOO.widget.TextNode(objRDFOWL, DITAcorevocabulary, false);
		var objReferenceanalysis = { label: "Reference analysis", href:"core_vocabulary/reference_analysis.html", target:"contentwin" };
    var Referenceanalysis = new YAHOO.widget.TextNode(objReferenceanalysis, DITAcorevocabulary, false);
		var objReferenceinformationtype = { label: "Reference information type", href:"core_vocabulary/reference_infotype.html", target:"contentwin" };
    var Referenceinformationtype = new YAHOO.widget.TextNode(objReferenceinformationtype, DITAcorevocabulary, false);
		var objRelatedlinkselementrelatedlinks = { label: "Related links element (<related-links>)", href:"core_vocabulary/related_links_element.html", target:"contentwin" };
    var Relatedlinkselementrelatedlinks = new YAHOO.widget.TextNode(objRelatedlinkselementrelatedlinks, DITAcorevocabulary, false);
		var objRelationshiptable = { label: "Relationship table", href:"core_vocabulary/relationship_table.html", target:"contentwin" };
    var Relationshiptable = new YAHOO.widget.TextNode(objRelationshiptable, DITAcorevocabulary, false);
		var objresultelementresult = { label: "result element (<result>)", href:"core_vocabulary/result_element.html", target:"contentwin" };
    var resultelementresult = new YAHOO.widget.TextNode(objresultelementresult, DITAcorevocabulary, false);
		var objReuseconceptsandtechniques = { label: "Reuse concepts and techniques", href:"core_vocabulary/reuse.html", target:"contentwin" };
    var Reuseconceptsandtechniques = new YAHOO.widget.TextNode(objReuseconceptsandtechniques, DITAcorevocabulary, false);
		var objSAXONXSLTprocessor = { label: "SAXON XSLT processor", href:"core_vocabulary/saxon.html", target:"contentwin" };
    var SAXONXSLTprocessor = new YAHOO.widget.TextNode(objSAXONXSLTprocessor, DITAcorevocabulary, false);
		var objSchema = { label: "Schema", href:"core_vocabulary/schema.html", target:"contentwin" };
    var Schema = new YAHOO.widget.TextNode(objSchema, DITAcorevocabulary, false);
		var objScopeattribute = { label: "Scope attribute", href:"core_vocabulary/scope_attribute.html", target:"contentwin" };
    var Scopeattribute = new YAHOO.widget.TextNode(objScopeattribute, DITAcorevocabulary, false);
		var objSearchtitleelementsearchtitle = { label: "Search title element (<searchtitle>)", href:"core_vocabulary/search_title_element.html", target:"contentwin" };
    var Searchtitleelementsearchtitle = new YAHOO.widget.TextNode(objSearchtitleelementsearchtitle, DITAcorevocabulary, false);
		var objShortdescription = { label: "Short description", href:"core_vocabulary/short_description.html", target:"contentwin" };
    var Shortdescription = new YAHOO.widget.TextNode(objShortdescription, DITAcorevocabulary, false);
		var objSimplelist = { label: "Simple list", href:"core_vocabulary/simple_list.html", target:"contentwin" };
    var Simplelist = new YAHOO.widget.TextNode(objSimplelist, DITAcorevocabulary, false);
		var objSimpletableelement = { label: "Simple table element", href:"core_vocabulary/simpletable_element.html", target:"contentwin" };
    var Simpletableelement = new YAHOO.widget.TextNode(objSimpletableelement, DITAcorevocabulary, false);
		var objSourceForgewebsite = { label: "SourceForge website", href:"core_vocabulary/sourceforge.html", target:"contentwin" };
    var SourceForgewebsite = new YAHOO.widget.TextNode(objSourceForgewebsite, DITAcorevocabulary, false);
		var objSpecializationinformationdesignreuse = { label: "Specialization (information design reuse)", href:"core_vocabulary/specialization.html", target:"contentwin" };
    var Specializationinformationdesignreuse = new YAHOO.widget.TextNode(objSpecializationinformationdesignreuse, DITAcorevocabulary, false);
		var objStepelement = { label: "Step element", href:"core_vocabulary/step_element.html", target:"contentwin" };
    var Stepelement = new YAHOO.widget.TextNode(objStepelement, DITAcorevocabulary, false);
		var objStructureelement = { label: "Structure element", href:"core_vocabulary/structure_element.html", target:"contentwin" };
    var Structureelement = new YAHOO.widget.TextNode(objStructureelement, DITAcorevocabulary, false);
		var objStylesheet = { label: "Stylesheet", href:"core_vocabulary/stylesheet.html", target:"contentwin" };
    var Stylesheet = new YAHOO.widget.TextNode(objStylesheet, DITAcorevocabulary, false);
		var objStaffmanager = { label: "Staff manager", href:"core_vocabulary/staff_manager.html", target:"contentwin" };
    var Staffmanager = new YAHOO.widget.TextNode(objStaffmanager, DITAcorevocabulary, false);
		var objTableelementtable = { label: "Table element (<table>)", href:"core_vocabulary/table_element.html", target:"contentwin" };
    var Tableelementtable = new YAHOO.widget.TextNode(objTableelementtable, DITAcorevocabulary, false);
		var objTechnologyspecialistaudiencecategory = { label: "Technology specialist audience category", href:"core_vocabulary/technology_specialist.html", target:"contentwin" };
    var Technologyspecialistaudiencecategory = new YAHOO.widget.TextNode(objTechnologyspecialistaudiencecategory, DITAcorevocabulary, false);
		var objTaskanalysis = { label: "Task analysis", href:"core_vocabulary/task_analysis.html", target:"contentwin" };
    var Taskanalysis = new YAHOO.widget.TextNode(objTaskanalysis, DITAcorevocabulary, false);
		var objTaskinformationtype = { label: "Task information type", href:"core_vocabulary/task_infotype.html", target:"contentwin" };
    var Taskinformationtype = new YAHOO.widget.TextNode(objTaskinformationtype, DITAcorevocabulary, false);
		var objTaskModeler = { label: "Task Modeler", href:"core_vocabulary/task_modeler.html", target:"contentwin" };
    var TaskModeler = new YAHOO.widget.TextNode(objTaskModeler, DITAcorevocabulary, false);
		var objTopicinformationtype = { label: "Topic information type", href:"core_vocabulary/topic_infotype.html", target:"contentwin" };
    var Topicinformationtype = new YAHOO.widget.TextNode(objTopicinformationtype, DITAcorevocabulary, false);
		var objtroff = { label: "troff", href:"core_vocabulary/troff.html", target:"contentwin" };
    var troff = new YAHOO.widget.TextNode(objtroff, DITAcorevocabulary, false);
		var objTypographicelement = { label: "Typographic element", href:"core_vocabulary/typographic_element.html", target:"contentwin" };
    var Typographicelement = new YAHOO.widget.TextNode(objTypographicelement, DITAcorevocabulary, false);
		var objUnorderedlistul = { label: "Unordered list (<ul>)", href:"core_vocabulary/unordered_list.html", target:"contentwin" };
    var Unorderedlistul = new YAHOO.widget.TextNode(objUnorderedlistul, DITAcorevocabulary, false);
		var objWebsitedesigner = { label: "Website designer", href:"core_vocabulary/website_designer.html", target:"contentwin" };
    var Websitedesigner = new YAHOO.widget.TextNode(objWebsitedesigner, DITAcorevocabulary, false);
		var objWordRTFRichTextFormat = { label: "Word RTF (Rich Text Format)", href:"core_vocabulary/wordrtf.html", target:"contentwin" };
    var WordRTFRichTextFormat = new YAHOO.widget.TextNode(objWordRTFRichTextFormat, DITAcorevocabulary, false);
		var objWriter = { label: "Writer", href:"core_vocabulary/writer.html", target:"contentwin" };
    var Writer = new YAHOO.widget.TextNode(objWriter, DITAcorevocabulary, false);
		var objXalanXSLTprocessor = { label: "Xalan XSLT processor", href:"core_vocabulary/xalan.html", target:"contentwin" };
    var XalanXSLTprocessor = new YAHOO.widget.TextNode(objXalanXSLTprocessor, DITAcorevocabulary, false);
		var objXHTML = { label: "XHTML", href:"core_vocabulary/xhtml.html", target:"contentwin" };
    var XHTML = new YAHOO.widget.TextNode(objXHTML, DITAcorevocabulary, false);
		var objXMLdeclaration = { label: "XML declaration", href:"core_vocabulary/xml_declaration.html", target:"contentwin" };
    var XMLdeclaration = new YAHOO.widget.TextNode(objXMLdeclaration, DITAcorevocabulary, false);
	
	
	

     tree.draw(); 
     } 
    
     YAHOO.util.Event.addListener(window, "load", treeInit); 
     